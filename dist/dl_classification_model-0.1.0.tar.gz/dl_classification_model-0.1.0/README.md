# dl-classification-model
Deep learning  model classification model for the water pumps project

This package in its actual stage is in for a specific purpose. By using it you are taking your own risks